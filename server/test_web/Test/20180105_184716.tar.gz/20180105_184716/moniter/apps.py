from django.apps import AppConfig


class MoniterConfig(AppConfig):
    name = 'moniter'
